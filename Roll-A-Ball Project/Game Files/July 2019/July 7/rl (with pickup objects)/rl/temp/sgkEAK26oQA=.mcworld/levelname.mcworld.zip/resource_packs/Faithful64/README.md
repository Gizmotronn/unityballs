# Faithful 64x64
Faithful 64 for Minecraft (Bedrock) BETA

# Downloading
https://github.com/LukasPlaysGames/Faithful-64x64/archive/master.zip 

(or click download repo as zip) No .mcpack support for developmental versions in this repository. If you are looking for stable builds, visit

http://www.mcpedl.com/faithful-pe

or

http://www.minecraftforum.net/forums/minecraft-pocket-edition/mcpe-texture-packs/2780034-1-0-x-1-1-x-1-2-x-faithful-64x-a-port-of

for STABLE pack revisions.

# This is a DEVELOPMENTAL repository for my version of Faithful 64x64 for Minecraft (Bedrock) BETAS
Due to the recent changes on Minecraft (Bedrock) betas, I am changing how updates to betas work. This repository will only be for the latest Minecraft BETA. For stable releases (not betas) of Minecraft, please use the links below. This repository is for Minecraft BETAS only.